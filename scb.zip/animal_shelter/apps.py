from django.apps import AppConfig


class AnimalShelterConfig(AppConfig):
    name = 'animal_shelter'
